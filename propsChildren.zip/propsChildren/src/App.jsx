import { useState ,useEffect} from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
   
function Increase({increase}){
  return(
    <div>
      <button onClick={increase} style={{position:"absolute", top:"70%", right:"70%", padding:"10px", borderRadius:"8px", border:"none", backgroundColor:"gray"}}>Increase Value</button>
    </div>
  )
}
function Decrease({decrease}){
  return(
    <div >
      <button onClick={decrease} style={{position:"absolute", top:"70%",right:"35%", padding:"10px", borderRadius:"8px" , border:"none", backgroundColor:"lightblue"}}>Decrease Value</button>
    </div>
  )
}
  
function Reset({reset}){
  return(
    <div>
      <button onClick={reset} style={{position:"absolute", top:"70%",right:"5%", padding:"10px", borderRadius:"8px" , border:"none" ,backgroundColor:"olive"}}>Reset Value</button>
    </div>
  )
}
function App() {
  let [count, setCount] = useState(0);

  function increaseCount() {
if(count<20){
  setCount(prevCount => prevCount + 1);
}  
else{
  alert("OOPS! Limit is Full")
}  
  }
  
  function decreaseCount() {
if(count>0){
  setCount(prevCount => prevCount - 1);
}  
else{
  alert("Vlaue Less Then Zero")
}  
  }
   function resetCount() {
if(count>0){
  setCount(count=0);
}  
else{
  alert("Vlaue Less Then Zero")
} 
   }
   
   useEffect(()=>{
    const time=setTimeout(()=>{
  alert("Count Value is Changed and useEffect is trigred")
    },3000)
  },[count,setCount])
   
  return (
          
   <div style={{display:"flex", justifyContent:"center", border:"2px solid gray" ,padding:"10px",margin:"10px", width:"400px", height:"300px", position:"absolute", left:"32%", top:"20%", borderRadius:"10px"}}>

            <h1 style={{display:"flex", position:"absolute", top:"25%", color:"lightcoral", border:"none",padding:"10px", borderRadius:"8px", backgroundColor:"lightgray"}}>Count:{count}</h1>
            <Increase increase={increaseCount}></Increase>
            <Decrease decrease={decreaseCount}></Decrease>
            <Reset reset={resetCount}></Reset>
            
    </div>

  )
}

export default App
